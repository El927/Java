package escuela;

public enum Materia{
    matemáticas,
    filosofía,
    física
}