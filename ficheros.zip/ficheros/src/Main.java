import java.io.*;

public class Main {
    public static void main(String[] args){
        try {
            readMyFile("archivo.txt");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
    public static void readMyFile(String archivo) throws IOException {
        try (FileReader read = new FileReader(archivo);){
            int caracter;
            while ((caracter = read.read()) != -1) {
                if (!Character.isWhitespace((char) caracter)) {
                    System.out.print((char) caracter);
                }
            }
        }
    }
}
